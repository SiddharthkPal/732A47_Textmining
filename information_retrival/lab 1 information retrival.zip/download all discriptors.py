# -*- coding: utf-8 -*-
"""
Created on Mon May 06 15:06:36 2013

@author: lyako297
"""
# gives the current folder to python
from __future__ import division
from bs4 import BeautifulSoup
import nltk, re#, pprint
import urllib2
import pickle
import os ,sys
# wd for script running : 
dirname, filename = os.path.split(os.path.abspath(__file__))
print "running from", dirname
print "file is", filename

# wd for coding
# os.chdir("\\\\neptunus.helix.ida.liu.se\\lyako297\\Documents\\atlas_sync\\732A47 Textmining\\lab\\lab 1 information retrival")
# dirname = os.getcwd()

base_url = "http://www.appbrain.com/"

#imitate a mozilla 5.0 web-browser
headers = { 'User-Agent' : 'Mozilla/5.0' }


def read_from_file(filename,wd=""):
    infile = open(filename,'rb')
    lista = pickle.load(infile)
    infile.close()
    return(lista)

# full_dir = os.listdir(dirname)
# del full_dir
pklfiles = [file for file in os.listdir(dirname) if file.endswith("pkl")]
# 19 * 200 appar

for fil in pklfiles:
    apps = read_from_file(pklfiles[0])
    

raw_input("Script Done !! \nPress Enter key to exit")
# this is for console "Run"
